To run the server, enter the command:
    javac TestServer.javac

then run:
    java TestServer

The server will show you a message indicating if it's working or not
if it fails to run, may God help you